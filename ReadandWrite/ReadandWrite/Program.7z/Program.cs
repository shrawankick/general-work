﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadandWrite
{
    class Program
    {
       
        static void Main(string[] args)
        {
            // Copied the Test folder to this directory for testing
            DirSearch(@"C:\temp\test\Selenium");
        }

        private static void Transform(string inputFile, string outputFile)
        {
            string strFile = ReadTextFile(inputFile);

            StringReader sr = new StringReader(strFile);
            string input;
            StringBuilder sb = new StringBuilder();
            int lineCounter = 0;
            while ((input = sr.ReadLine()) != null)
            {
                if (input.Contains("public class"))
                {
                    if (input.Contains("Base"))
                    {
                        return;
                    }
                    input += " : Base";
                }
                if (input.Contains("IWebDriver driver"))
                {
                    input = $"// {input}";
                }
                if (input.Contains("[SetUp]"))
                {
                    lineCounter += 1;
                }
                if ((lineCounter > 0) && (lineCounter <= 19))
                {
                    lineCounter += 1;
                    input = $"// {input}";
                }
                sb.Append(input);
                sb.Append("\r\n");
            }

            WriteTextFile(outputFile, sb.ToString());
        }

        /// <summary>
        /// From http://stackoverflow.com/a/929277
        /// </summary>
        /// <param name="sDir"></param>
        static void DirSearch(string sDir)
        {
            List<string> filePaths = new List<string>();
            try
            {
                foreach (string d in Directory.GetDirectories(sDir))
                {
                    foreach (string f in Directory.GetFiles(d))
                    {
                        Transform(f, f);
                    }
                    DirSearch(d);
                }
            }
            catch (System.Exception excpt)
            {
                Console.WriteLine(excpt.Message);
            }
        }

        public static string ReadTextFile(string filePath)
        {
            string strText = string.Empty;
            if (File.Exists(filePath))
            {
                StreamReader sr = new StreamReader(File.OpenRead(filePath));
                strText = sr.ReadToEnd();
                sr.Close();
            }
            return strText;
        }

        public static void WriteTextFile(string filePath, string dataStr)
        {
            StreamWriter sr = File.CreateText(filePath);
            sr.Write(dataStr);
            sr.Close();


        }
    }
}
